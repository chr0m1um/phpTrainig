<?php
    // генератор 100 000 000 000 000 різних варіантів вірша
    $string = 'poems/strings.txt'; // заходимо в тхт файл
    $line = file($string); // зчитуємо рядки і поміщаємо в масив за допомогою функції
    echo $line[rand(0,9)].'<br>'.$line[rand(10,19)].'<br>'.$line[rand(20,29)].'<br>'.$line[rand(30,39)].'<br>'.'<br>'.
    $line[rand(40,49)].'<br>'.$line[rand(50,59)].'<br>'.$line[rand(60,69)].'<br>'.$line[rand(70,79)].'<br>'.'<br>'.
    $line[rand(80,89)].'<br>'.$line[rand(90,99)].'<br>'.$line[rand(100,109)].'<br>'.'<br>'.$line[rand(110,119)].'<br>'.
    $line[rand(120,129)].'<br>'.$line[rand(130,139)]; // вибираємо випадковий рядок 

/*
    // для можливості генерації кожного рядка окремо
    $string1 = 'poems/str1.txt';
    $line1 = file($string1); 
    echo $line1[rand(0,9)].'<br>'; 
    
    $string2 = 'poems/str2.txt';
    $line2 = file($string2); 
    echo $line2[rand(0,9)].'<br>';
    
    $string3 = 'poems/str3.txt';
    $line3 = file($string3); 
    echo $line3[rand(0,9)].'<br>';
    
    $string4 = 'poems/str4.txt';
    $line4 = file($string4); 
    echo $line4[rand(0,9)].'<br>';
    
    $string5 = 'poems/str5.txt';
    $line5 = file($string5); 
    echo $line5[rand(0,9)].'<br>';
    
    $string6 = 'poems/str6.txt';
    $line6 = file($string6); 
    echo $line6[rand(0,9)].'<br>';
    
    $string7 = 'poems/str7.txt';
    $line7 = file($string7); 
    echo $line7[rand(0,9)].'<br>';
    
    $string8 = 'poems/str8.txt';
    $line8 = file($string8); 
    echo $line8[rand(0,9)].'<br>';
    
    $string9 = 'poems/str9.txt';
    $line9 = file($string9); 
    echo $line9[rand(0,9)].'<br>';
    
    $string10 = 'poems/str10.txt';
    $line10 = file($string10); 
    echo $line10[rand(0,9)].'<br>';
    
    $string11 = 'poems/str11.txt';
    $line11 = file($string11); 
    echo $line11[rand(0,9)].'<br>';
    
    $string12 = 'poems/str12.txt';
    $line12 = file($string12); 
    echo $line12[rand(0,9)].'<br>';
    
    $string13 = 'poems/str13.txt';
    $line13 = file($string13); 
    echo $line13[rand(0,9)].'<br>';
    
    $string14 = 'poems/str14.txt';
    $line14 = file($string14); 
    echo $line14[rand(0,9)].'<br>';
    */

?>